<?php
declare(strict_types=1);

require_once __DIR__ . '/BaseModel.php';

class CrawlQueueModel extends BaseModel
{
    public function getStats(): array
    {
        return $this->pdo->query(
            "SELECT trang_thai, COUNT(*) AS n FROM crawl_queue GROUP BY trang_thai"
        )->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    public function getFilteredCount(array $filters): int
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = 'trang_thai = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $where[] = 'url LIKE ?';
            $params[] = '%' . $filters['search'] . '%';
        }

        $whereSQL = implode(' AND ', $where);
        $s = $this->pdo->prepare("SELECT COUNT(*) FROM crawl_queue WHERE {$whereSQL}");
        $s->execute($params);
        return (int) $s->fetchColumn();
    }

    public function getFilteredList(array $filters, int $limit, int $offset): array
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = 'trang_thai = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $where[] = 'url LIKE ?';
            $params[] = '%' . $filters['search'] . '%';
        }

        $whereSQL = implode(' AND ', $where);
        $s = $this->pdo->prepare("
            SELECT * FROM crawl_queue
            WHERE {$whereSQL}
            ORDER BY id ASC
            LIMIT ? OFFSET ?
        ");
        $s->execute(array_merge($params, [$limit, $offset]));
        return $s->fetchAll();
    }
}

